# MikoPBX extension module template #

*Read this in other languages: [English](README.md), [Русский](README.ru.md).*

## Module description ##

We are working on the module developing guide here [https://docs.mikopbx.com](https://docs.mikopbx.com/mikopbx-development/)


### Questions ###
You are welcome to our telegram channel for developers [@mikopbx_dev](https://t.me/joinchat/AAPn5xSqZIpQnNnCAa3bBw)
