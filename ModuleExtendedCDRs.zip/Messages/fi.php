<?php
return [
    /**
 * Copyright (C) MIKO LLC - All Rights Reserved
 * Unauthorized copying of this file, via any medium is strictly prohibited
 * Proprietary and confidential
 * Written by Nikolay Beketov, 6 2018
 *
 */
    'repModuleExtendedCDRs' => '',
    'mo_ModuleModuleExtendedCDRs' => '',
    'BreadcrumbModuleExtendedCDRs' => '',
    'SubHeaderModuleExtendedCDRs' => '',
    'repModuleExtendedCDRs_FindCallsPlaceholder' => '',
    'repModuleExtendedCDRs_TitleOutgoingCals' => '',
    'repModuleExtendedCDRs_TitleIncomingCals' => '',
    'repModuleExtendedCDRs_TitleMissedCals' => '',
    'repModuleExtendedCDRs_TitleExportTab' => '',
    'repModuleExtendedCDRs_TitleExportToHttpTab' => '',
    'repModuleExtendedCDRs_TitleOtherFilter' => '',
    'repModuleExtendedCDRs_PlaceholderFilter' => '',
    'repModuleExtendedCDRs_cdr_ColumnWaitTime' => '',
    'repModuleExtendedCDRs_cdr_ColumnLine' => '',
    'repModuleExtendedCDRs_cdr_ColumnCallState' => '',
    'repModuleExtendedCDRs_cdr_ColumnTypeState' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_OK' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_TRANSFER' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_MISSED' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_OUTGOING_FAIL' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_RECALL_CLIENT' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_RECALL_USER' => '',
    'repModuleExtendedCDRs_cdr_CALL_STATE_APPLICATION' => '',
    'repModuleExtendedCDRs_cdr_CALL_TYPE_INNER' => '',
    'repModuleExtendedCDRs_cdr_CALL_TYPE_OUTGOING' => '',
    'repModuleExtendedCDRs_cdr_CALL_TYPE_INCOMING' => '',
    'repModuleExtendedCDRs_cdr_CALL_TYPE_MISSED' => '',
    'repModuleExtendedCDRs_syncState' => '',
    'repModuleExtendedCDRs_cdr_cal_Today' => '',
    'repModuleExtendedCDRs_cdr_cal_Yesterday' => '',
    'repModuleExtendedCDRs_cdr_cal_LastWeek' => '',
    'repModuleExtendedCDRs_cdr_cal_Last30Days' => '',
    'repModuleExtendedCDRs_cdr_cal_ThisMonth' => '',
    'repModuleExtendedCDRs_cdr_cal_LastMonth' => '',
];
