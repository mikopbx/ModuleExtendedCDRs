# Шаблон модуля расширения для MikoPBX

_Read this in other languages:_ [_English_](./)_,_ [_Русский_](readme.ru.md)_._

## Описание модуля расширения

Документацию по разработке и установке собственного модуля можно найти по ссылке [https://docs.mikopbx.com](https://docs.mikopbx.com/mikopbx-development/)

### Вопросы

Подключайтесь к каналу для разрабочиков в telegram [@mikopbx\_dev](https://t.me/joinchat/AAPn5xSqZIpQnNnCAa3bBw)

